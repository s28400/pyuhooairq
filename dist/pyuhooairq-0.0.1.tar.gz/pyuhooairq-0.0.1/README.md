# pyuhooairq

Python interface for uhoo air quality sensors.
More details coming soon.